import subprocess
prompt="hello"
subprocess.run(["ollama", "run", "llama3.2",prompt],
)
