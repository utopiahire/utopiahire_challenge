// Global script for navigation and small interactions
document.addEventListener('click', e=>{
  // make stat boxes keyboard accessible
  const stat = e.target.closest('.stat-box, .card.small');
  if(stat && stat.dataset.href){
    window.location.href = stat.dataset.href;
  }
});

// Analyse CV simple interaction (already embedded in analyse page but keep here for reuse)
function analyseCV(){
  const res = document.getElementById('resultat');
  if(res) res.classList.remove('hidden');
}

// Interview page helpers (camera + mic)
let mediaStream = null;
let mediaRecorder = null;
let recordedChunks = [];

async function openCamera(){
  try{
    mediaStream = await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    const videoEl = document.querySelector('#localVideo');
    if(videoEl) videoEl.srcObject = mediaStream;
  }catch(err){
    alert('Accès caméra/micro refusé ou non disponible: '+err.message);
  }
}

function startRecording(){
  if(!mediaStream){
    alert('Ouvrez d\u00ababord la caméra');
    return;
  }
  recordedChunks = [];
  mediaRecorder = new MediaRecorder(mediaStream);
  mediaRecorder.ondataavailable = e=>{ if(e.data.size>0) recordedChunks.push(e.data); };
  mediaRecorder.onstop = ()=>{
    const blob = new Blob(recordedChunks,{type:'audio/webm'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'interview_recording.webm'; a.textContent='Télécharger l\'enregistrement';
    const wrap = document.querySelector('#recordingLink'); wrap.innerHTML=''; wrap.appendChild(a);
  };
  mediaRecorder.start();
}

function stopRecording(){
  if(mediaRecorder && mediaRecorder.state!=='inactive') mediaRecorder.stop();
}

// Utility: when leaving interview room stop tracks
function stopAllTracks(){
  if(mediaStream){
    mediaStream.getTracks().forEach(t=>t.stop());
    mediaStream=null;
  }
}

window.addEventListener('beforeunload', stopAllTracks);

// Small helper to navigate from dashboard to linked pages
function goTo(h){ window.location.href=h }
