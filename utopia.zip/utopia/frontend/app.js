// REGISTER USER
function register() {
    const user = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
        phone: document.getElementById("phone").value,
        location: document.getElementById("location").value,
        title: document.getElementById("title").value,
        experience: document.getElementById("experience").value,
        bio: document.getElementById("bio").value,
        skills: document.getElementById("skills").value.split(","),
        languages: document.getElementById("languages").value.split(",")
    };

    localStorage.setItem("user", JSON.stringify(user));
    alert("Account created!");
    window.location.href = "signin.html";
}

// LOGIN
function login() {
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user) {
        alert("No account created yet.");
        return;
    }

    if (
        user.email === document.getElementById("email").value &&
        user.password === document.getElementById("password").value
    ) {
        localStorage.setItem("loggedIn", "1");
        window.location.href = "profile.html";
    } else {
        alert("Incorrect email or password");
    }
}

// LOAD PROFILE PAGE
if (window.location.pathname.includes("profile.html")) {

    if (!localStorage.getItem("loggedIn")) {
        window.location.href = "signin.html";
    }

    const user = JSON.parse(localStorage.getItem("user"));

    document.getElementById("profile-name").value = user.name;
    document.getElementById("profile-email").value = user.email;
    document.getElementById("profile-phone").value = user.phone;
    document.getElementById("profile-location").value = user.location;
    document.getElementById("profile-title").value = user.title;
    document.getElementById("profile-experience").value = user.experience;
    document.getElementById("profile-bio").value = user.bio;

    // First letter in photo
    document.getElementById("profile-photo").innerText = user.name[0];

    // skills tags
    user.skills.forEach(s => {
        if (s.trim() !== "") {
            document.getElementById("profile-skills").innerHTML +=
                `<span class="tag">${s.trim()}</span>`;
        }
    });

    user.languages.forEach(l => {
        if (l.trim() !== "") {
            document.getElementById("profile-languages").innerHTML +=
                `<span class="tag">${l.trim()}</span>`;
        }
    });
}
