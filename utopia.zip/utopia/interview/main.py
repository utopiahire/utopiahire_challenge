from fastapi import FastAPI
import os
import json
from testWhisper import start_transcription, stop_transcription, TRANSCRIPTION_DIR
import uvicorn
app = FastAPI(title="Whisper Realtime Server")

@app.get("/")
def root():
    return {"message": "🚀 Whisper Realtime Server is running!"}

@app.post("/start")
def start():
    msg = start_transcription()
    return {"status": "ok", "message": msg}

@app.post("/stop")
def stop():
    msg = stop_transcription()
    return {"status": "ok", "message": msg}

@app.get("/transcriptions")
def list_transcriptions():
    """Liste les fichiers JSON disponibles."""
    files = sorted(os.listdir(TRANSCRIPTION_DIR))
    return {"count": len(files), "files": files}

@app.get("/transcription/{filename}")
def get_transcription(filename: str):
    """Récupère une transcription précise."""
    path = os.path.join(TRANSCRIPTION_DIR, filename)
    if not os.path.exists(path):
        return {"error": "Fichier non trouvé."}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data
if __name__ == "__main__":
    
    uvicorn.run("main:app", host="0.0.0.0", port=8005, reload=True)
