from TTS.api import TTS
import torch
import sounddevice as sd
import numpy as np

use_cuda = torch.cuda.is_available()
print(f"🚀 Utilisation du GPU : {use_cuda}")

tts = TTS(model_name="tts_models/multilingual/multi-dataset/your_tts",
          progress_bar=False,
          gpu=use_cuda)

print("🎤 Voix disponibles :", tts.speakers)
speaker = tts.speakers[3]
print(f"🗣️ Voix sélectionnée : {speaker}")

print("📢 Tapez un texte, puis appuyez sur Entrée. Tapez 'exit' pour quitter.")

while True:
    text = input("Vous : ")
    if text.lower() == "exit":
        break

    # Générer audio en mémoire
    wav = tts.tts(text=text, speaker=speaker, language="en")

    # Jouer directement
    sd.play(wav, samplerate=tts.synthesizer.output_sample_rate)
    sd.wait()
