import sounddevice as sd
import numpy as np
import whisper
import torch
import queue
import threading

# ✅ Charger le modèle Whisper Medium
print("⏳ Chargement du modèle Whisper Medium...")
model = whisper.load_model("medium", device="cuda" if torch.cuda.is_available() else "cpu")
print("✅ Modèle chargé avec succès !")

# File pour stocker les données audio
audio_queue = queue.Queue()

# Paramètres audio
sample_rate = 16000
block_size = 8000  # durée d'un bloc sonore

def audio_callback(indata, frames, time, status):
    if status:
        print(status)
    audio_queue.put(indata.copy())

# Thread pour la transcription en continu
def transcribe_stream():
    print("🎙️ Transcription temps réel en cours... (Ctrl+C pour arrêter)")
    audio_buffer = np.zeros((0, 1), dtype=np.float32)

    while True:
        block = audio_queue.get()
        audio_buffer = np.concatenate((audio_buffer, block), axis=0)

        # Transcrire toutes les 5 secondes environ
        if len(audio_buffer) > sample_rate * 5:
            audio_data = audio_buffer.flatten()
            result = model.transcribe(audio_data, fp16=torch.cuda.is_available(), language="en")
            print("🗣️", result["text"])
            audio_buffer = np.zeros((0, 1), dtype=np.float32)

# Démarrer la capture micro
with sd.InputStream(samplerate=sample_rate, channels=1, callback=audio_callback):
    threading.Thread(target=transcribe_stream, daemon=True).start()
    input("🎧 Parle dans ton micro... Appuie sur Entrée pour arrêter.\n")
