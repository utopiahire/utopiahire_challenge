import sounddevice as sd
import numpy as np
import whisper
import torch
import queue
import threading
import json
import os
from datetime import datetime
import requests

# ------------------- Variables globales -------------------
model = None
sample_rate = 16000
block_size = 8000
audio_queue = queue.Queue()
is_running = False
audio_stream = None
transcription_text = ""
current_file_path = None

# Dossier pour les transcriptions
TRANSCRIPTION_DIR = "transcriptionsv2"
os.makedirs(TRANSCRIPTION_DIR, exist_ok=True)

# URL de ton ami pour recevoir les transcriptions
FRIEND_ENDPOINT = "http://IP_AMI:PORT/receive_transcription"  # <-- à modifier

# ------------------- Fonctions -------------------
def load_model():
    """Charge le modèle Whisper si nécessaire."""
    global model
    if model is None:
        print("⏳ Chargement du modèle Whisper Small...")
        model = whisper.load_model("small", device="cuda" if torch.cuda.is_available() else "cpu")
        print("✅ Modèle chargé avec succès !")

def audio_callback(indata, frames, time, status):
    """Callback pour récupérer les données audio du micro."""
    if status:
        print(status)
    audio_queue.put(indata.copy())

def save_transcription(text: str):
    """Sauvegarde le texte cumulatif dans le fichier JSON courant."""
    global current_file_path
    if current_file_path is None:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        current_file_path = os.path.join(TRANSCRIPTION_DIR, f"transcription_{timestamp}.json")
    data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "text": text
    }
    with open(current_file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def transcribe_stream():
    """Thread de transcription continue."""
    global is_running, transcription_text
    is_running = True
    transcription_text = ""
    print("🎙️ Transcription temps réel démarrée...")

    audio_buffer = np.zeros((0, 1), dtype=np.float32)

    while is_running:
        block = audio_queue.get()
        audio_buffer = np.concatenate((audio_buffer, block), axis=0)

        # Transcrire toutes les ~5 secondes
        if len(audio_buffer) > sample_rate * 5:
            audio_data = audio_buffer.flatten()
            result = model.transcribe(audio_data, fp16=torch.cuda.is_available(), language="en")
            text = result["text"].strip()
            if text:
                print("🗣️", text)
                transcription_text += " " + text
                save_transcription(transcription_text)
            audio_buffer = np.zeros((0, 1), dtype=np.float32)

def start_transcription():
    """Démarre le micro + le thread de transcription."""
    global is_running, audio_stream, current_file_path
    if is_running:
        return "Transcription déjà en cours."

    load_model()
    current_file_path = None
    threading.Thread(target=transcribe_stream, daemon=True).start()

    audio_stream = sd.InputStream(samplerate=sample_rate, channels=1, callback=audio_callback)
    audio_stream.start()

    is_running = True
    return "Transcription démarrée."

def stop_transcription():
    """Arrête la transcription et envoie la transcription à ton ami."""
    global is_running, audio_stream, transcription_text
    is_running = False

    if audio_stream is not None:
        audio_stream.stop()
        audio_stream.close()
        audio_stream = None

    # Sauvegarde finale
    if transcription_text.strip():
        save_transcription(transcription_text)
        print("✅ Transcription finale enregistrée.")

        # ------------------- Envoi automatique à l'ami -------------------
        if FRIEND_ENDPOINT:
            payload = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "text": transcription_text,
                "extra_info": "Session terminée"
            }
            try:
                response = requests.post(FRIEND_ENDPOINT, json=payload)
                print(f"✅ Transcription envoyée à ton ami, status: {response.status_code}")

                # ------------------- Récupérer le JSON de réponse -------------------
                response_data = response.json()
                print("📥 Réponse de ton ami:", response_data)

                # Sauvegarder la réponse dans un fichier local
                response_file = os.path.join(TRANSCRIPTION_DIR, "response_from_friend.json")
                with open(response_file, "w", encoding="utf-8") as f:
                    json.dump(response_data, f, ensure_ascii=False, indent=4)
                print(f"✅ Réponse sauvegardée dans {response_file}")

            except Exception as e:
                print(f"❌ Erreur lors de l'envoi au ami: {e}")

    return "Transcription arrêtée."
