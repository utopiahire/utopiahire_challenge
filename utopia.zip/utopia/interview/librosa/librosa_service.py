from fastapi import FastAPI, UploadFile, File
import tempfile
import os
from main import extract_features  # <-- import your function

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Librosa API is running successfully!"}

@app.post("/analyze_audio")
async def analyze_audio(file: UploadFile = File(...), handicap: bool = True):
    # Save the uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name

    # Run your existing function
    result = extract_features(tmp_path, handicap=handicap)

    # Clean up temporary file
    os.remove(tmp_path)

    return result
