import librosa
import numpy as np
import os

def extract_features(file_path, handicap=True):
    y, sr = librosa.load(file_path, sr=16000)

    # -------------------
    # RMS (energy)
    # -------------------
    rms = librosa.feature.rms(y=y)[0]
    rms_mean = float(np.mean(rms))

    # -------------------
    # Pitch (f0)
    # -------------------
    f0, _, _ = librosa.pyin(y, fmin=50, fmax=400)
    valid_f0 = f0[~np.isnan(f0)]
    pitch = float(np.mean(valid_f0)) if len(valid_f0) > 0 else 0.0
    pitch_var = np.var(valid_f0) if len(valid_f0) > 0 else 1000
    pitch_stability = np.clip((pitch_var / 3000), 0, 1)

    # -------------------
    # Jitter
    # -------------------
    pitch_diff = np.diff(valid_f0)
    jitter = float(np.mean(np.abs(pitch_diff))) if len(pitch_diff) > 0 else 0.0
    jitter_norm = np.clip(1 - (jitter / 20), 0, 1)

    # -------------------
    # MFCC (clarity proxy)
    # -------------------
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    mfcc = float(np.mean(mfccs))
    mfcc_var = np.mean(np.var(mfccs, axis=1))
    clarity_norm = np.clip(1 - (mfcc_var / 2000), 0, 1)

    # -------------------
    # Silence / Hesitation
    # -------------------
    silence_ratio = float(np.sum(rms < 0.01) / len(rms))
    hesitation = int(np.sum(rms < 0.01))

    # -------------------
    # Handicap adaptation
    # -------------------
    if handicap:
        # flatten penalties to make scoring more forgiving
        clarity_norm = 0.7 * clarity_norm + 0.3
        pitch_stability = 0.8 * pitch_stability + 0.2
        jitter_norm = 0.8 * jitter_norm + 0.2

    # -------------------
    # Final score
    # -------------------
    # Formula logic:
    # - High clarity, stable pitch, moderate jitter, low silence → high score
    # - Invert jitter effect: high jitter in expressive speech isn't penalized
    score = (
        0.40 * clarity_norm +
        0.40 * pitch_stability +
        0.05 * jitter_norm +
        0.10 * (1 - silence_ratio)
    )
    score = np.clip(score, 0, 1)
    final_score = round(score * 100, 2)

    # -------------------
    # Return features
    # -------------------
    return {
        "file": os.path.basename(file_path),
        "handicap_mode": handicap,
        "pitch": round(pitch, 3),
        "rms": round(rms_mean, 3),
        "jitter": round(jitter, 3),
        "mfcc": round(mfcc, 3),
        "silence_ratio": round(silence_ratio, 3),
        "hesitation": hesitation,
        "final_score": float(final_score)
    }







# ============================
# Example: Batch processing
# ============================
folder = "/home/chahd/Documents/tsyp project/librosa/samples"
handicap = False # or False depending on the interviewee input

for filename in os.listdir(folder):
    if filename.endswith((".wav", ".flac")):
        result = extract_features(os.path.join(folder, filename), handicap=handicap)
        print(result)
