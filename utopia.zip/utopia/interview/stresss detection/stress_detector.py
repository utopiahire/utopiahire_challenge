import cv2
from deepface import DeepFace
import matplotlib.pyplot as plt
import time

# --- Analyse de la face ---
def analyze_face(frame):
    try:
        result = DeepFace.analyze(frame, actions=['emotion'], enforce_detection=False)
        return result[0]['emotion']
    except:
        return None

# --- Calcul du score pondéré ---
def compute_stress_weighted(emotions_dict):
    stress_weights = {
        "fear": 1.0,
        "angry": 0.8,
        "sad": 0.6,
        "disgust": 0.5,
        "neutral": 0.2,
        "happy": 0.0,
        "surprise": 0.4
    }

    stress_score = 0.0
    total_weight = 0.0
    for emotion, proba in emotions_dict.items():
        stress_score += stress_weights.get(emotion, 0) * (proba / 100)
        total_weight += (proba / 100)

    return stress_score / total_weight if total_weight != 0 else 0

# --- Graphique final ---
def plot_stress_over_time(stress_scores, timestamps):
    plt.figure(figsize=(8, 5))
    plt.plot(timestamps, stress_scores, color='red', linewidth=2)
    plt.title("Évolution du stress facial (1 mesure/seconde)")
    plt.xlabel("Temps (secondes)")
    plt.ylabel("Niveau de stress (0–1)")
    plt.grid(True)

    # Sauvegarde en image et PDF
    plt.savefig("stress_curve.png", dpi=300, bbox_inches='tight')
    plt.savefig("stress_curve.pdf", dpi=300, bbox_inches='tight')

    print("\n✅ Graphique sauvegardé :")
    print("   📁 stress_curve.png")
    print("   📁 stress_curve.pdf")

    plt.show(block=True)

# --- Programme principal ---
def run_realtime_stress_analysis():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ Erreur : impossible d’ouvrir la webcam.")
        return

    stress_scores = []
    timestamps = []
    start_time = time.time()
    last_update_time = start_time
    stress_display = 0.0  # Dernière valeur affichée

    print("🎥 Webcam ouverte — Appuie sur 'q' pour quitter.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        current_time = time.time()
        elapsed_time = current_time - start_time

        # Mise à jour toutes les 1 seconde
        if current_time - last_update_time >= 1.0:
            emotions = analyze_face(frame)
            if emotions:
                stress = compute_stress_weighted(emotions)
                stress_display = stress
                stress_scores.append(stress)
                timestamps.append(int(elapsed_time))
                print(f"🕒 {int(elapsed_time)}s -> Stress={stress:.2f} | {emotions}")
            last_update_time = current_time

        # Affichage du score sur l’écran
        cv2.putText(frame, f"Stress: {stress_display:.2f}", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 255, 255), 2)

        cv2.imshow("UtopiaHire - Real-time Stress Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    print(f"\n📊 Nombre total de mesures : {len(stress_scores)}")
    if stress_scores:
        plot_stress_over_time(stress_scores, timestamps)
    else:
        print("⚠️ Aucune donnée détectée.")

# --- Lancement ---
if __name__ == "__main__":
    run_realtime_stress_analysis()
